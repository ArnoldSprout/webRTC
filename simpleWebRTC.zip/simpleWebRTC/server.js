const express = require('express');

const app = express()
const port = 3000

//set public folder root
asserts.use(express.static('public'));

//provide access to node_modules folder from the client-side
app.use('/scripts', express.static(`${__dirname}/node_modules`));

//redirect all traffic to index.html
app.use((req, res) => res.sendFile(`${__dirname}/public/index.html`));

app.listen(port, () => {
    console.info('listening on %d', port);
});