# Simple WebRTC Messenge

Building a WebRTC video chat app using SimpleWebRTC
